# ATLAS ⊙ — Site public

Architecture cognitive pour la collaboration humain-IA.

**Stack :** Next.js 14 · App Router · Styled-components · Framer Motion · TypeScript

---

## Démarrage local

```bash
npm install
npm run dev
```

→ Ouvre [http://localhost:3000](http://localhost:3000)

---

## Déploiement GitHub + Vercel

### 1. Créer le repo GitHub

```bash
# Depuis le dossier du projet
git init
git add .
git commit -m "init: ATLAS site ⊙"
```

Puis sur [github.com](https://github.com) :
- Cliquer **New repository**
- Nommer le repo : `atlas-public`
- Laisser **Public** coché
- Ne pas initialiser avec README (tu en as déjà un)
- Cliquer **Create repository**

Puis connecter :

```bash
git remote add origin https://github.com/TON_USERNAME/atlas-public.git
git branch -M main
git push -u origin main
```

### 2. Déployer sur Vercel

1. Aller sur [vercel.com](https://vercel.com)
2. **Add New → Project**
3. Sélectionner le repo `atlas-public`
4. Vercel détecte automatiquement Next.js
5. Cliquer **Deploy**

C'est tout. Vercel génère une URL publique (ex: `atlas-public.vercel.app`).

Chaque `git push` sur `main` redéploie automatiquement.

---

## Structure du projet

```
src/
  app/
    layout.tsx        # Layout racine + fonts
    page.tsx          # Page principale
    globals.css       # Reset CSS + variables
  components/
    Navigation.tsx    # Nav fixe + toggle FR/EN
    Hero.tsx          # Section hero
    SpiralDiagram.tsx # Spirale animée SVG
    LoiMere.tsx       # Loi Mère interactive
    OSection.tsx      # O — Orbitalité
    Couches.tsx       # C1→C10 grid interactive
    Agents.tsx        # Quadripôle
    Modes.tsx         # 5 modes
    Vivo.tsx          # VIVO checks + footer
  lib/
    lang.tsx          # Contexte FR/EN
    translations.ts   # Toutes les traductions
    registry.tsx      # SSR styled-components
```

---

## Personnalisation

- **Couleur signal** : modifier `--signal: #0057FF` dans `globals.css`
- **Fonts** : modifier les imports Google Fonts dans `layout.tsx`
- **Contenu** : tout est dans `src/lib/translations.ts`

---

*⊚₀ → 0 → 1 → O → un → ∞ → ⊚₀⁺ · La boucle ne se ferme pas. Elle monte.*
